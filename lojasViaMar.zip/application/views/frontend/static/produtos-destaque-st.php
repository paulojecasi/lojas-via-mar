 
				<li>
          <img src="<?php echo "./assets/frontend/img/products/d3d9446802a44259755d38e6d163e820.jpg"; ?>" >
          <div class="caption-group">
              <h2 class="caption title title-product-destaque">
              		<?php echo substr(wordwrap("Mochila Escolar Seanite Florida MJ14020 Com Estojo Feminina - Azul", 33,"<br />\n"),0,100); ?>
                   <br>
              </h2>
              
              <br> 
              <h1 class="caption title" >
                  <?php 
                  if ("0,00" > "0,00" && "0,00" < "252,99"):
                  ?> 
                      <span class="primary"> 
                          <?php echo "De R$ 252,99"; ?>
                          <br> 
                          <strong>
                              <?php echo "Por R$ 0,00"; ?>
                          </strong>
                      </span>
                  <?php
                  else:
                  ?>
                      <span class="primary"> 
                          Apenas R$
                          <strong> <?php echo "252,99"; ?> </strong>
                      </span>
                  <?php
                  endif;
                  ?>

              </h1>
           
              <h4 class="caption subtitle"> </h4>
              <a class="caption button-radius" href="<?php echo base_url('home/detalhe_produto/d3d9446802a44259755d38e6d163e820'); ?>">
                  <span class="icon"></span>
                  Mais detalhes
              </a>
          </div>
      </li>
				

    	 
				<li>
          <img src="<?php echo "./assets/frontend/img/products/aab3238922bcc25a6f606eb525ffdc56.jpg"; ?>" >
          <div class="caption-group">
              <h2 class="caption title title-product-destaque">
              		<?php echo substr(wordwrap("Boneca de pano simples  ", 33,"<br />\n"),0,100); ?>
                   <br>
              </h2>
              
              <br> 
              <h1 class="caption title" >
                  <?php 
                  if ("58,99" > "0,00" && "58,99" < "80,00"):
                  ?> 
                      <span class="primary"> 
                          <?php echo "De R$ 80,00"; ?>
                          <br> 
                          <strong>
                              <?php echo "Por R$ 58,99"; ?>
                          </strong>
                      </span>
                  <?php
                  else:
                  ?>
                      <span class="primary"> 
                          Apenas R$
                          <strong> <?php echo "80,00"; ?> </strong>
                      </span>
                  <?php
                  endif;
                  ?>

              </h1>
           
              <h4 class="caption subtitle"> </h4>
              <a class="caption button-radius" href="<?php echo base_url('home/detalhe_produto/aab3238922bcc25a6f606eb525ffdc56'); ?>">
                  <span class="icon"></span>
                  Mais detalhes
              </a>
          </div>
      </li>
				

    	 
				<li>
          <img src="<?php echo "./assets/frontend/img/products/9bf31c7ff062936a96d3c8bd1f8f2ff3.jpg"; ?>" >
          <div class="caption-group">
              <h2 class="caption title title-product-destaque">
              		<?php echo substr(wordwrap("Pulseira de Bijuteria Bolinha ", 33,"<br />\n"),0,100); ?>
                   <br>
              </h2>
              
              <br> 
              <h1 class="caption title" >
                  <?php 
                  if ("0,00" > "0,00" && "0,00" < "4,99"):
                  ?> 
                      <span class="primary"> 
                          <?php echo "De R$ 4,99"; ?>
                          <br> 
                          <strong>
                              <?php echo "Por R$ 0,00"; ?>
                          </strong>
                      </span>
                  <?php
                  else:
                  ?>
                      <span class="primary"> 
                          Apenas R$
                          <strong> <?php echo "4,99"; ?> </strong>
                      </span>
                  <?php
                  endif;
                  ?>

              </h1>
           
              <h4 class="caption subtitle"> </h4>
              <a class="caption button-radius" href="<?php echo base_url('home/detalhe_produto/9bf31c7ff062936a96d3c8bd1f8f2ff3'); ?>">
                  <span class="icon"></span>
                  Mais detalhes
              </a>
          </div>
      </li>
				

    	 
				<li>
          <img src="<?php echo "./assets/frontend/img/products/6512bd43d9caa6e02c990b0a82652dca.jpg"; ?>" >
          <div class="caption-group">
              <h2 class="caption title title-product-destaque">
              		<?php echo substr(wordwrap("Óculos de Sol SPY 51 - Madox", 33,"<br />\n"),0,100); ?>
                   <br>
              </h2>
              
              <br> 
              <h1 class="caption title" >
                  <?php 
                  if ("0,00" > "0,00" && "0,00" < "225,00"):
                  ?> 
                      <span class="primary"> 
                          <?php echo "De R$ 225,00"; ?>
                          <br> 
                          <strong>
                              <?php echo "Por R$ 0,00"; ?>
                          </strong>
                      </span>
                  <?php
                  else:
                  ?>
                      <span class="primary"> 
                          Apenas R$
                          <strong> <?php echo "225,00"; ?> </strong>
                      </span>
                  <?php
                  endif;
                  ?>

              </h1>
           
              <h4 class="caption subtitle"> </h4>
              <a class="caption button-radius" href="<?php echo base_url('home/detalhe_produto/6512bd43d9caa6e02c990b0a82652dca'); ?>">
                  <span class="icon"></span>
                  Mais detalhes
              </a>
          </div>
      </li>
				

    	 
				<li>
          <img src="<?php echo "./assets/frontend/img/products/c20ad4d76fe97759aa27a0c99bff6710.jpg"; ?>" >
          <div class="caption-group">
              <h2 class="caption title title-product-destaque">
              		<?php echo substr(wordwrap("Bolsa Grande Preta Tote Given", 33,"<br />\n"),0,100); ?>
                   <br>
              </h2>
              
              <br> 
              <h1 class="caption title" >
                  <?php 
                  if ("258,97" > "0,00" && "258,97" < "398,98"):
                  ?> 
                      <span class="primary"> 
                          <?php echo "De R$ 398,98"; ?>
                          <br> 
                          <strong>
                              <?php echo "Por R$ 258,97"; ?>
                          </strong>
                      </span>
                  <?php
                  else:
                  ?>
                      <span class="primary"> 
                          Apenas R$
                          <strong> <?php echo "398,98"; ?> </strong>
                      </span>
                  <?php
                  endif;
                  ?>

              </h1>
           
              <h4 class="caption subtitle"> </h4>
              <a class="caption button-radius" href="<?php echo base_url('home/detalhe_produto/c20ad4d76fe97759aa27a0c99bff6710'); ?>">
                  <span class="icon"></span>
                  Mais detalhes
              </a>
          </div>
      </li>
				

    	 
				<li>
          <img src="<?php echo "./assets/frontend/img/products/c51ce410c124a10e0db5e4b97fc2af39.jpg"; ?>" >
          <div class="caption-group">
              <h2 class="caption title title-product-destaque">
              		<?php echo substr(wordwrap("Makiê Profissional For You - Paleta de Sombras 40x1,3g", 33,"<br />\n"),0,100); ?>
                   <br>
              </h2>
              
              <br> 
              <h1 class="caption title" >
                  <?php 
                  if ("0,00" > "0,00" && "0,00" < "258,99"):
                  ?> 
                      <span class="primary"> 
                          <?php echo "De R$ 258,99"; ?>
                          <br> 
                          <strong>
                              <?php echo "Por R$ 0,00"; ?>
                          </strong>
                      </span>
                  <?php
                  else:
                  ?>
                      <span class="primary"> 
                          Apenas R$
                          <strong> <?php echo "258,99"; ?> </strong>
                      </span>
                  <?php
                  endif;
                  ?>

              </h1>
           
              <h4 class="caption subtitle"> </h4>
              <a class="caption button-radius" href="<?php echo base_url('home/detalhe_produto/c51ce410c124a10e0db5e4b97fc2af39'); ?>">
                  <span class="icon"></span>
                  Mais detalhes
              </a>
          </div>
      </li>
				

    	 
				<li>
          <img src="<?php echo "./assets/frontend/img/products/3c59dc048e8850243be8079a5c74d079.jpg"; ?>" >
          <div class="caption-group">
              <h2 class="caption title title-product-destaque">
              		<?php echo substr(wordwrap("Radio Pilha Am Fm Vintage Retro Radinho Bivolt Fone P2", 33,"<br />\n"),0,100); ?>
                   <br>
              </h2>
              
              <br> 
              <h1 class="caption title" >
                  <?php 
                  if ("0,00" > "0,00" && "0,00" < "144,50"):
                  ?> 
                      <span class="primary"> 
                          <?php echo "De R$ 144,50"; ?>
                          <br> 
                          <strong>
                              <?php echo "Por R$ 0,00"; ?>
                          </strong>
                      </span>
                  <?php
                  else:
                  ?>
                      <span class="primary"> 
                          Apenas R$
                          <strong> <?php echo "144,50"; ?> </strong>
                      </span>
                  <?php
                  endif;
                  ?>

              </h1>
           
              <h4 class="caption subtitle"> </h4>
              <a class="caption button-radius" href="<?php echo base_url('home/detalhe_produto/3c59dc048e8850243be8079a5c74d079'); ?>">
                  <span class="icon"></span>
                  Mais detalhes
              </a>
          </div>
      </li>
				

    	 
				<li>
          <img src="<?php echo "./assets/frontend/img/products/b6d767d2f8ed5d21a44b0e5886680cb9.jpg"; ?>" >
          <div class="caption-group">
              <h2 class="caption title title-product-destaque">
              		<?php echo substr(wordwrap("Rádio Antigo Vintage Retrô A-1088 Altomex Fm Am Pendrive Sd", 33,"<br />\n"),0,100); ?>
                   <br>
              </h2>
              
              <br> 
              <h1 class="caption title" >
                  <?php 
                  if ("0,00" > "0,00" && "0,00" < "131,90"):
                  ?> 
                      <span class="primary"> 
                          <?php echo "De R$ 131,90"; ?>
                          <br> 
                          <strong>
                              <?php echo "Por R$ 0,00"; ?>
                          </strong>
                      </span>
                  <?php
                  else:
                  ?>
                      <span class="primary"> 
                          Apenas R$
                          <strong> <?php echo "131,90"; ?> </strong>
                      </span>
                  <?php
                  endif;
                  ?>

              </h1>
           
              <h4 class="caption subtitle"> </h4>
              <a class="caption button-radius" href="<?php echo base_url('home/detalhe_produto/b6d767d2f8ed5d21a44b0e5886680cb9'); ?>">
                  <span class="icon"></span>
                  Mais detalhes
              </a>
          </div>
      </li>
				

    	 
				<li>
          <img src="<?php echo "./assets/frontend/img/products/4e732ced3463d06de0ca9a15b6153677.jpg"; ?>" >
          <div class="caption-group">
              <h2 class="caption title title-product-destaque">
              		<?php echo substr(wordwrap("Carrinho de controle remoto 4 x4", 33,"<br />\n"),0,100); ?>
                   <br>
              </h2>
              
              <br> 
              <h1 class="caption title" >
                  <?php 
                  if ("0,00" > "0,00" && "0,00" < "290,00"):
                  ?> 
                      <span class="primary"> 
                          <?php echo "De R$ 290,00"; ?>
                          <br> 
                          <strong>
                              <?php echo "Por R$ 0,00"; ?>
                          </strong>
                      </span>
                  <?php
                  else:
                  ?>
                      <span class="primary"> 
                          Apenas R$
                          <strong> <?php echo "290,00"; ?> </strong>
                      </span>
                  <?php
                  endif;
                  ?>

              </h1>
           
              <h4 class="caption subtitle"> </h4>
              <a class="caption button-radius" href="<?php echo base_url('home/detalhe_produto/4e732ced3463d06de0ca9a15b6153677'); ?>">
                  <span class="icon"></span>
                  Mais detalhes
              </a>
          </div>
      </li>
				

    	 
				<li>
          <img src="<?php echo "./assets/frontend/img/products/02e74f10e0327ad868d138f2b4fdd6f0.jpg"; ?>" >
          <div class="caption-group">
              <h2 class="caption title title-product-destaque">
              		<?php echo substr(wordwrap("Guitarra Gianine", 33,"<br />\n"),0,100); ?>
                   <br>
              </h2>
              
              <br> 
              <h1 class="caption title" >
                  <?php 
                  if ("0,00" > "0,00" && "0,00" < "490,00"):
                  ?> 
                      <span class="primary"> 
                          <?php echo "De R$ 490,00"; ?>
                          <br> 
                          <strong>
                              <?php echo "Por R$ 0,00"; ?>
                          </strong>
                      </span>
                  <?php
                  else:
                  ?>
                      <span class="primary"> 
                          Apenas R$
                          <strong> <?php echo "490,00"; ?> </strong>
                      </span>
                  <?php
                  endif;
                  ?>

              </h1>
           
              <h4 class="caption subtitle"> </h4>
              <a class="caption button-radius" href="<?php echo base_url('home/detalhe_produto/02e74f10e0327ad868d138f2b4fdd6f0'); ?>">
                  <span class="icon"></span>
                  Mais detalhes
              </a>
          </div>
      </li>
				

    	 
				<li>
          <img src="<?php echo "./assets/frontend/img/products/33e75ff09dd601bbe69f351039152189.jpg"; ?>" >
          <div class="caption-group">
              <h2 class="caption title title-product-destaque">
              		<?php echo substr(wordwrap("Mochila Bolsa Resistente , Notebook 15.6 Saida Usb E Fone", 33,"<br />\n"),0,100); ?>
                   <br>
              </h2>
              
              <br> 
              <h1 class="caption title" >
                  <?php 
                  if ("0,00" > "0,00" && "0,00" < "134,00"):
                  ?> 
                      <span class="primary"> 
                          <?php echo "De R$ 134,00"; ?>
                          <br> 
                          <strong>
                              <?php echo "Por R$ 0,00"; ?>
                          </strong>
                      </span>
                  <?php
                  else:
                  ?>
                      <span class="primary"> 
                          Apenas R$
                          <strong> <?php echo "134,00"; ?> </strong>
                      </span>
                  <?php
                  endif;
                  ?>

              </h1>
           
              <h4 class="caption subtitle"> </h4>
              <a class="caption button-radius" href="<?php echo base_url('home/detalhe_produto/33e75ff09dd601bbe69f351039152189'); ?>">
                  <span class="icon"></span>
                  Mais detalhes
              </a>
          </div>
      </li>
				

    	 
				<li>
          <img src="<?php echo "./assets/frontend/img/products/6ea9ab1baa0efb9e19094440c317e21b.jpg"; ?>" >
          <div class="caption-group">
              <h2 class="caption title title-product-destaque">
              		<?php echo substr(wordwrap("Colar Life Citrino Ágata Rodolita e Lápis Lazuli", 33,"<br />\n"),0,100); ?>
                   <br>
              </h2>
              
              <br> 
              <h1 class="caption title" >
                  <?php 
                  if ("800,00" > "0,00" && "800,00" < "1.290,00"):
                  ?> 
                      <span class="primary"> 
                          <?php echo "De R$ 1.290,00"; ?>
                          <br> 
                          <strong>
                              <?php echo "Por R$ 800,00"; ?>
                          </strong>
                      </span>
                  <?php
                  else:
                  ?>
                      <span class="primary"> 
                          Apenas R$
                          <strong> <?php echo "1.290,00"; ?> </strong>
                      </span>
                  <?php
                  endif;
                  ?>

              </h1>
           
              <h4 class="caption subtitle"> </h4>
              <a class="caption button-radius" href="<?php echo base_url('home/detalhe_produto/6ea9ab1baa0efb9e19094440c317e21b'); ?>">
                  <span class="icon"></span>
                  Mais detalhes
              </a>
          </div>
      </li>
				

    	 
				<li>
          <img src="<?php echo "./assets/frontend/img/products/34173cb38f07f89ddbebc2ac9128303f.jpg"; ?>" >
          <div class="caption-group">
              <h2 class="caption title title-product-destaque">
              		<?php echo substr(wordwrap("Colar Life Citrino Ágata Rodolita e Lápis Lazuli", 33,"<br />\n"),0,100); ?>
                   <br>
              </h2>
              
              <br> 
              <h1 class="caption title" >
                  <?php 
                  if ("0,00" > "0,00" && "0,00" < "98,00"):
                  ?> 
                      <span class="primary"> 
                          <?php echo "De R$ 98,00"; ?>
                          <br> 
                          <strong>
                              <?php echo "Por R$ 0,00"; ?>
                          </strong>
                      </span>
                  <?php
                  else:
                  ?>
                      <span class="primary"> 
                          Apenas R$
                          <strong> <?php echo "98,00"; ?> </strong>
                      </span>
                  <?php
                  endif;
                  ?>

              </h1>
           
              <h4 class="caption subtitle"> </h4>
              <a class="caption button-radius" href="<?php echo base_url('home/detalhe_produto/34173cb38f07f89ddbebc2ac9128303f'); ?>">
                  <span class="icon"></span>
                  Mais detalhes
              </a>
          </div>
      </li>
				

    	 
				<li>
          <img src="<?php echo "./assets/frontend/img/products/c16a5320fa475530d9583c34fd356ef5.jpg"; ?>" >
          <div class="caption-group">
              <h2 class="caption title title-product-destaque">
              		<?php echo substr(wordwrap("KIT C/10 PULSEIRAS LIFE ATACADO BIJUTERIA", 33,"<br />\n"),0,100); ?>
                   <br>
              </h2>
              
              <br> 
              <h1 class="caption title" >
                  <?php 
                  if ("60,00" > "0,00" && "60,00" < "79,00"):
                  ?> 
                      <span class="primary"> 
                          <?php echo "De R$ 79,00"; ?>
                          <br> 
                          <strong>
                              <?php echo "Por R$ 60,00"; ?>
                          </strong>
                      </span>
                  <?php
                  else:
                  ?>
                      <span class="primary"> 
                          Apenas R$
                          <strong> <?php echo "79,00"; ?> </strong>
                      </span>
                  <?php
                  endif;
                  ?>

              </h1>
           
              <h4 class="caption subtitle"> </h4>
              <a class="caption button-radius" href="<?php echo base_url('home/detalhe_produto/c16a5320fa475530d9583c34fd356ef5'); ?>">
                  <span class="icon"></span>
                  Mais detalhes
              </a>
          </div>
      </li>
				

    	 
				<li>
          <img src="<?php echo "./assets/frontend/img/products/6364d3f0f495b6ab9dcf8d3b5c6e0b01.jpg"; ?>" >
          <div class="caption-group">
              <h2 class="caption title title-product-destaque">
              		<?php echo substr(wordwrap("Brinco de Bijuteria Casual Modelo 66", 33,"<br />\n"),0,100); ?>
                   <br>
              </h2>
              
              <br> 
              <h1 class="caption title" >
                  <?php 
                  if ("0,00" > "0,00" && "0,00" < "7,99"):
                  ?> 
                      <span class="primary"> 
                          <?php echo "De R$ 7,99"; ?>
                          <br> 
                          <strong>
                              <?php echo "Por R$ 0,00"; ?>
                          </strong>
                      </span>
                  <?php
                  else:
                  ?>
                      <span class="primary"> 
                          Apenas R$
                          <strong> <?php echo "7,99"; ?> </strong>
                      </span>
                  <?php
                  endif;
                  ?>

              </h1>
           
              <h4 class="caption subtitle"> </h4>
              <a class="caption button-radius" href="<?php echo base_url('home/detalhe_produto/6364d3f0f495b6ab9dcf8d3b5c6e0b01'); ?>">
                  <span class="icon"></span>
                  Mais detalhes
              </a>
          </div>
      </li>
				

    	 
				<li>
          <img src="<?php echo "./assets/frontend/img/products/182be0c5cdcd5072bb1864cdee4d3d6e.jpg"; ?>" >
          <div class="caption-group">
              <h2 class="caption title title-product-destaque">
              		<?php echo substr(wordwrap("Brincos BJU super chique", 33,"<br />\n"),0,100); ?>
                   <br>
              </h2>
              
              <br> 
              <h1 class="caption title" >
                  <?php 
                  if ("0,00" > "0,00" && "0,00" < "22,99"):
                  ?> 
                      <span class="primary"> 
                          <?php echo "De R$ 22,99"; ?>
                          <br> 
                          <strong>
                              <?php echo "Por R$ 0,00"; ?>
                          </strong>
                      </span>
                  <?php
                  else:
                  ?>
                      <span class="primary"> 
                          Apenas R$
                          <strong> <?php echo "22,99"; ?> </strong>
                      </span>
                  <?php
                  endif;
                  ?>

              </h1>
           
              <h4 class="caption subtitle"> </h4>
              <a class="caption button-radius" href="<?php echo base_url('home/detalhe_produto/182be0c5cdcd5072bb1864cdee4d3d6e'); ?>">
                  <span class="icon"></span>
                  Mais detalhes
              </a>
          </div>
      </li>
				

    	 
				<li>
          <img src="<?php echo "./assets/frontend/img/products/e369853df766fa44e1ed0ff613f563bd.jpg"; ?>" >
          <div class="caption-group">
              <h2 class="caption title title-product-destaque">
              		<?php echo substr(wordwrap("Bolsa Lenna's Casual", 33,"<br />\n"),0,100); ?>
                   <br>
              </h2>
              
              <br> 
              <h1 class="caption title" >
                  <?php 
                  if ("0,00" > "0,00" && "0,00" < "89,00"):
                  ?> 
                      <span class="primary"> 
                          <?php echo "De R$ 89,00"; ?>
                          <br> 
                          <strong>
                              <?php echo "Por R$ 0,00"; ?>
                          </strong>
                      </span>
                  <?php
                  else:
                  ?>
                      <span class="primary"> 
                          Apenas R$
                          <strong> <?php echo "89,00"; ?> </strong>
                      </span>
                  <?php
                  endif;
                  ?>

              </h1>
           
              <h4 class="caption subtitle"> </h4>
              <a class="caption button-radius" href="<?php echo base_url('home/detalhe_produto/e369853df766fa44e1ed0ff613f563bd'); ?>">
                  <span class="icon"></span>
                  Mais detalhes
              </a>
          </div>
      </li>
				

    	 
				<li>
          <img src="<?php echo "./assets/frontend/img/products/a5771bce93e200c36f7cd9dfd0e5deaa.jpg"; ?>" >
          <div class="caption-group">
              <h2 class="caption title title-product-destaque">
              		<?php echo substr(wordwrap("Kit Beyoung Make Inteligente", 33,"<br />\n"),0,100); ?>
                   <br>
              </h2>
              
              <br> 
              <h1 class="caption title" >
                  <?php 
                  if ("0,00" > "0,00" && "0,00" < "168,95"):
                  ?> 
                      <span class="primary"> 
                          <?php echo "De R$ 168,95"; ?>
                          <br> 
                          <strong>
                              <?php echo "Por R$ 0,00"; ?>
                          </strong>
                      </span>
                  <?php
                  else:
                  ?>
                      <span class="primary"> 
                          Apenas R$
                          <strong> <?php echo "168,95"; ?> </strong>
                      </span>
                  <?php
                  endif;
                  ?>

              </h1>
           
              <h4 class="caption subtitle"> </h4>
              <a class="caption button-radius" href="<?php echo base_url('home/detalhe_produto/a5771bce93e200c36f7cd9dfd0e5deaa'); ?>">
                  <span class="icon"></span>
                  Mais detalhes
              </a>
          </div>
      </li>
				

    	 
				<li>
          <img src="<?php echo "./assets/frontend/img/products/d67d8ab4f4c10bf22aa353e27879133c.jpg"; ?>" >
          <div class="caption-group">
              <h2 class="caption title title-product-destaque">
              		<?php echo substr(wordwrap("Contorno Facial Em Bastão Pele Clara 14g", 33,"<br />\n"),0,100); ?>
                   <br>
              </h2>
              
              <br> 
              <h1 class="caption title" >
                  <?php 
                  if ("0,00" > "0,00" && "0,00" < "40,00"):
                  ?> 
                      <span class="primary"> 
                          <?php echo "De R$ 40,00"; ?>
                          <br> 
                          <strong>
                              <?php echo "Por R$ 0,00"; ?>
                          </strong>
                      </span>
                  <?php
                  else:
                  ?>
                      <span class="primary"> 
                          Apenas R$
                          <strong> <?php echo "40,00"; ?> </strong>
                      </span>
                  <?php
                  endif;
                  ?>

              </h1>
           
              <h4 class="caption subtitle"> </h4>
              <a class="caption button-radius" href="<?php echo base_url('home/detalhe_produto/d67d8ab4f4c10bf22aa353e27879133c'); ?>">
                  <span class="icon"></span>
                  Mais detalhes
              </a>
          </div>
      </li>
				

    	 
				<li>
          <img src="<?php echo "./assets/frontend/img/products/d645920e395fedad7bbbed0eca3fe2e0.jpg"; ?>" >
          <div class="caption-group">
              <h2 class="caption title title-product-destaque">
              		<?php echo substr(wordwrap("Maleta De Maquiagem Miss Rose Profissional 142 Itens", 33,"<br />\n"),0,100); ?>
                   <br>
              </h2>
              
              <br> 
              <h1 class="caption title" >
                  <?php 
                  if ("350,00" > "0,00" && "350,00" < "378,00"):
                  ?> 
                      <span class="primary"> 
                          <?php echo "De R$ 378,00"; ?>
                          <br> 
                          <strong>
                              <?php echo "Por R$ 350,00"; ?>
                          </strong>
                      </span>
                  <?php
                  else:
                  ?>
                      <span class="primary"> 
                          Apenas R$
                          <strong> <?php echo "378,00"; ?> </strong>
                      </span>
                  <?php
                  endif;
                  ?>

              </h1>
           
              <h4 class="caption subtitle"> </h4>
              <a class="caption button-radius" href="<?php echo base_url('home/detalhe_produto/d645920e395fedad7bbbed0eca3fe2e0'); ?>">
                  <span class="icon"></span>
                  Mais detalhes
              </a>
          </div>
      </li>
				

    	