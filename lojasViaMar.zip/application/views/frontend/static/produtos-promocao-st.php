 
				<div class="col-md-3 col-sm-6">
					<a href = "<?php echo base_url('home/detalhe_produto/aab3238922bcc25a6f606eb525ffdc56'); ?>"> 
				
					    <div class="single-shop-product">
					        <div class="product-upper">
					            <h1 class="img-lista-produto">
					                <?php echo img('./assets/frontend/img/products/aab3238922bcc25a6f606eb525ffdc56.jpg','class="img-fluid"'); ?>
					            </h1>
					        </div>

					        <br> 
					        <h2>
					        	<a href="<?php echo base_url('home/detalhe_produto/aab3238922bcc25a6f606eb525ffdc56'); ?>"> <?php echo 'Boneca de pano simples  '; ?>
					        	</a>
					        </h2>

					        <div class="product-carousel-price">
					            <?php 
					            if ("58,99 > 0"):
					            ?>
					                <del>
					                    <?php echo "De R$ 80,00 por" ?>
					                </del>
					                <br> 
					                <ins>
					                	<?php echo "R$ 58,99" ?> 
					                </ins>
					 
					            <?php
					            else:
					            ?>
					                <br> 
					                <ins>
					                	<?php echo "R$ 80,00" ?> 
					                </ins>
					            <?php
					            endif;
					            ?>
					       		</div>  
					                             
					    	</div>
						</a>
					</div>
    	 
				<div class="col-md-3 col-sm-6">
					<a href = "<?php echo base_url('home/detalhe_produto/c20ad4d76fe97759aa27a0c99bff6710'); ?>"> 
				
					    <div class="single-shop-product">
					        <div class="product-upper">
					            <h1 class="img-lista-produto">
					                <?php echo img('./assets/frontend/img/products/c20ad4d76fe97759aa27a0c99bff6710.jpg','class="img-fluid"'); ?>
					            </h1>
					        </div>

					        <br> 
					        <h2>
					        	<a href="<?php echo base_url('home/detalhe_produto/c20ad4d76fe97759aa27a0c99bff6710'); ?>"> <?php echo 'Bolsa Grande Preta Tote Given'; ?>
					        	</a>
					        </h2>

					        <div class="product-carousel-price">
					            <?php 
					            if ("258,97 > 0"):
					            ?>
					                <del>
					                    <?php echo "De R$ 398,98 por" ?>
					                </del>
					                <br> 
					                <ins>
					                	<?php echo "R$ 258,97" ?> 
					                </ins>
					 
					            <?php
					            else:
					            ?>
					                <br> 
					                <ins>
					                	<?php echo "R$ 398,98" ?> 
					                </ins>
					            <?php
					            endif;
					            ?>
					       		</div>  
					                             
					    	</div>
						</a>
					</div>
    	 
				<div class="col-md-3 col-sm-6">
					<a href = "<?php echo base_url('home/detalhe_produto/6ea9ab1baa0efb9e19094440c317e21b'); ?>"> 
				
					    <div class="single-shop-product">
					        <div class="product-upper">
					            <h1 class="img-lista-produto">
					                <?php echo img('./assets/frontend/img/products/6ea9ab1baa0efb9e19094440c317e21b.jpg','class="img-fluid"'); ?>
					            </h1>
					        </div>

					        <br> 
					        <h2>
					        	<a href="<?php echo base_url('home/detalhe_produto/6ea9ab1baa0efb9e19094440c317e21b'); ?>"> <?php echo 'Colar Life Citrino Ágata Rodolita e Lápis Lazuli'; ?>
					        	</a>
					        </h2>

					        <div class="product-carousel-price">
					            <?php 
					            if ("800,00 > 0"):
					            ?>
					                <del>
					                    <?php echo "De R$ 1.290,00 por" ?>
					                </del>
					                <br> 
					                <ins>
					                	<?php echo "R$ 800,00" ?> 
					                </ins>
					 
					            <?php
					            else:
					            ?>
					                <br> 
					                <ins>
					                	<?php echo "R$ 1.290,00" ?> 
					                </ins>
					            <?php
					            endif;
					            ?>
					       		</div>  
					                             
					    	</div>
						</a>
					</div>
    	 
				<div class="col-md-3 col-sm-6">
					<a href = "<?php echo base_url('home/detalhe_produto/c16a5320fa475530d9583c34fd356ef5'); ?>"> 
				
					    <div class="single-shop-product">
					        <div class="product-upper">
					            <h1 class="img-lista-produto">
					                <?php echo img('./assets/frontend/img/products/c16a5320fa475530d9583c34fd356ef5.jpg','class="img-fluid"'); ?>
					            </h1>
					        </div>

					        <br> 
					        <h2>
					        	<a href="<?php echo base_url('home/detalhe_produto/c16a5320fa475530d9583c34fd356ef5'); ?>"> <?php echo 'KIT C/10 PULSEIRAS LIFE ATACADO BIJUTERIA'; ?>
					        	</a>
					        </h2>

					        <div class="product-carousel-price">
					            <?php 
					            if ("60,00 > 0"):
					            ?>
					                <del>
					                    <?php echo "De R$ 79,00 por" ?>
					                </del>
					                <br> 
					                <ins>
					                	<?php echo "R$ 60,00" ?> 
					                </ins>
					 
					            <?php
					            else:
					            ?>
					                <br> 
					                <ins>
					                	<?php echo "R$ 79,00" ?> 
					                </ins>
					            <?php
					            endif;
					            ?>
					       		</div>  
					                             
					    	</div>
						</a>
					</div>
    	 
				<div class="col-md-3 col-sm-6">
					<a href = "<?php echo base_url('home/detalhe_produto/d645920e395fedad7bbbed0eca3fe2e0'); ?>"> 
				
					    <div class="single-shop-product">
					        <div class="product-upper">
					            <h1 class="img-lista-produto">
					                <?php echo img('./assets/frontend/img/products/d645920e395fedad7bbbed0eca3fe2e0.jpg','class="img-fluid"'); ?>
					            </h1>
					        </div>

					        <br> 
					        <h2>
					        	<a href="<?php echo base_url('home/detalhe_produto/d645920e395fedad7bbbed0eca3fe2e0'); ?>"> <?php echo 'Maleta De Maquiagem Miss Rose Profissional 142 Itens'; ?>
					        	</a>
					        </h2>

					        <div class="product-carousel-price">
					            <?php 
					            if ("350,00 > 0"):
					            ?>
					                <del>
					                    <?php echo "De R$ 378,00 por" ?>
					                </del>
					                <br> 
					                <ins>
					                	<?php echo "R$ 350,00" ?> 
					                </ins>
					 
					            <?php
					            else:
					            ?>
					                <br> 
					                <ins>
					                	<?php echo "R$ 378,00" ?> 
					                </ins>
					            <?php
					            endif;
					            ?>
					       		</div>  
					                             
					    	</div>
						</a>
					</div>
    	 
				<div class="col-md-3 col-sm-6">
					<a href = "<?php echo base_url('home/detalhe_produto/19ca14e7ea6328a42e0eb13d585e4c22'); ?>"> 
				
					    <div class="single-shop-product">
					        <div class="product-upper">
					            <h1 class="img-lista-produto">
					                <?php echo img('./assets/frontend/img/products/19ca14e7ea6328a42e0eb13d585e4c22.jpg','class="img-fluid"'); ?>
					            </h1>
					        </div>

					        <br> 
					        <h2>
					        	<a href="<?php echo base_url('home/detalhe_produto/19ca14e7ea6328a42e0eb13d585e4c22'); ?>"> <?php echo 'Carteira Masculina Em Couro - 123310 Marrom UNI'; ?>
					        	</a>
					        </h2>

					        <div class="product-carousel-price">
					            <?php 
					            if ("195,00 > 0"):
					            ?>
					                <del>
					                    <?php echo "De R$ 230,00 por" ?>
					                </del>
					                <br> 
					                <ins>
					                	<?php echo "R$ 195,00" ?> 
					                </ins>
					 
					            <?php
					            else:
					            ?>
					                <br> 
					                <ins>
					                	<?php echo "R$ 230,00" ?> 
					                </ins>
					            <?php
					            endif;
					            ?>
					       		</div>  
					                             
					    	</div>
						</a>
					</div>
    	