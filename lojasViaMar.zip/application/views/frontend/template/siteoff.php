<div class="site-branding-area area-logo">
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-12">
        <div class="logo text-center">
           <h1> 
              
                <img class="img-fluid" src="<?php echo base_url('/assets/frontend/img/logo44.png') ?>" >
            
           </h1>
        </div>
      </div>
    </div>
  </div>
</div>

		
<div class="alert alert-warning text-center" role="alert">
  <h1> Estamos em Manutenção, em breve voltaremos! </h1>
</div>