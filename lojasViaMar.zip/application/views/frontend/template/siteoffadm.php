
<div class="alert alert-warning text-center" role="alert">
  <h1> Site OFFLINE, liberado somente para o Administrador </h1>
</div>