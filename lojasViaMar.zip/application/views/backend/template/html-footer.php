    <!-- jQuery -->
    <script src="<?php echo base_url('assets/backend/js/jquery.min.js') ?>"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url('assets/backend/js/bootstrap.min.js') ?>"></script>

    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url('assets/backend/js/sb-admin-2.js') ?>"></script>

</body>

</html>