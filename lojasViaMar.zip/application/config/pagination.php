<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['full_tag_open']= "<ul class='pagination'>";
$config['full_tag_close']= "</ul>";
$config['first_tag_open']= "<li class='paginate_button'>";
$config['first_tag_close']= "</li>";
$config['prev_tag_open']= "<li class='paginate_button'>";
$config['prev_tag_close']= "</li>";
$config['prev_tag_open']= "<li class='paginate_button'>";
$config['prev_tag_close']= "</li>";
$config['cur_tag_open']= "<li class='paginate_button active'>
	<a href='javascript:null'>";
$config['cur_tag_close']= "</a></li>";
$config['num_tag_open']= "<li class='paginate_button'>";
$config['num_tag_close']= "</li>";
$config['next_tag_open']= "<li class='paginate_button'>";
$config['next_tag_close']= "</li>";
$config['last_tag_open']= "<li class='paginate_button'>";
$config['last_tag_close']= "</li>";
$config['first_link']='<i class="glyphicon glyphicon-fast-backward"></i> Primeiro';
$config['prev_link']='<i class="glyphicon glyphicon-backward"></i> Anterior';
$config['next_link']='<i class="glyphicon glyphicon-forward"></i> Próximo';
$config['last_link']='<i class="glyphicon glyphicon-fast-forward"></i> Ultimo';
